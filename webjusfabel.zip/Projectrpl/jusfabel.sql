-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jan 04, 2025 at 11:03 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.0.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `urbantopia`
--

-- --------------------------------------------------------

--
-- Table structure for table `kategori`
--

CREATE TABLE `kategori` (
  `id` int(11) NOT NULL,
  `nama` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `kategori`
--

INSERT INTO `kategori` (`id`, `nama`) VALUES
(1, 'Lampu'),
(3, 'Wall Decor'),
(5, 'Carpet');

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE `orders` (
  `id` int(11) NOT NULL,
  `nama_pembeli` varchar(100) NOT NULL,
  `alamat` text NOT NULL,
  `email` varchar(100) NOT NULL,
  `contact` varchar(15) NOT NULL,
  `nama_produk` varchar(100) NOT NULL,
  `harga` decimal(10,2) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `orders`
--

INSERT INTO `orders` (`id`, `nama_pembeli`, `alamat`, `email`, `contact`, `nama_produk`, `harga`, `created_at`) VALUES
(8, 'pulan', 'puri bintaro', 'pulan@diadiad.com', '02123123113', 'Gold Line Wall Decor', 200000.00, '2025-01-03 11:36:09'),
(9, 'pulan', 'cisauk', 'pulan@diadiad.com', '02123123113', 'Lampu Hias Gantung Merah', 300000.00, '2025-01-03 11:37:06'),
(10, 'adelio', 'puri bintaro', 'adellio121202@gmaill.com', '02123123123', 'Comfortable Gold Variant Carpet', 150000.00, '2025-01-04 09:51:40');

-- --------------------------------------------------------

--
-- Table structure for table `produk`
--

CREATE TABLE `produk` (
  `id` int(11) NOT NULL,
  `kategori_id` int(11) NOT NULL,
  `nama` varchar(100) NOT NULL,
  `foto` varchar(255) DEFAULT NULL,
  `detail` text DEFAULT NULL,
  `stok` enum('Habis','Tersedia') DEFAULT 'Tersedia',
  `harga` double DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `produk`
--

INSERT INTO `produk` (`id`, `kategori_id`, `nama`, `foto`, `detail`, `stok`, `harga`) VALUES
(3, 1, 'Lampu Hias Gantung Merah', 'YKwMD7uwPSy6zH5vUJLh.jpeg', 'Lampu hias gantung LED warna merah                                                                                                                                                  ', 'Tersedia', 300000),
(4, 1, 'Lampu Hias Tabung', 'PvDGaYiWoDEnhSdimqkO.jpeg', 'Lampu hias LED tabung warna cokelat muda                                                                                         ', 'Tersedia', 250000),
(5, 5, 'Natural Carpet', 'otPdVPQZbxEGpKyYAwis.jpeg', 'Karpet dengan desain yang natural warna cokelat                                                                                   ', 'Tersedia', 150000),
(6, 3, 'Gold Line Wall Decor', 'slJy7dGHudz2DWj0UYWI.jpeg', 'Wall decor garis warna emas                                                  ', 'Tersedia', 200000),
(7, 3, 'Vintage Wall Hanging Vase Wooden', 'rU1WamWYMOuJ0uBIi4t3.jpeg', 'Hiasan dinding vas bunga gantung kayu             ', 'Tersedia', 100000),
(8, 3, 'Vintage Wall Hexagon ', '38fISjOnoyzNoYuGfaUc.jpeg', 'Hiasan dinding hexagon untuk tempat aksesoris         ', 'Tersedia', 198000),
(9, 1, 'Lampu Hias Hitam', '63I7CpNSr6p3ZIDAp0q8.jpeg', 'Lampu hias warna hitam desain unik          ', 'Tersedia', 350000),
(10, 5, 'Soft Comfortable Carpet ', '8kdLhLru0WKXN3adv40s.jpeg', 'Karpet lantai empuk nyaman warna merah, gold, silver      ', 'Tersedia', 100000),
(11, 5, 'Comfortable Gold Variant Carpet', 'uLJF9YmpCklEzfzltwvY.jpg', 'Karpet nyaman varian warna gold           ', 'Tersedia', 150000),
(12, 1, 'Lampu Hias Gold Circle', 'TOECxFkutOI6FOeRq8Kq.jpeg', 'Lampu hias dengan desain circle warna gold             ', 'Tersedia', 500000),
(18, 1, 'Lampu Hias Putih', 'mStRM8XkuwoqrS9mu9FU.jpeg', 'Lampu LED hias warna putih', 'Tersedia', 150000),
(19, 1, 'Lampu Hias 3 Circle ', 'bDyfYfVHWCykvExAI9F7.jpeg', 'Lampu hias 3 circle LED ', 'Tersedia', 250000),
(20, 3, 'Black Cloud Hiasan Dinding', 'EEsaRmqu2bma73qPtqqE.jpeg', 'Hiasan dinding awan hitam ', 'Tersedia', 300000),
(21, 3, 'Circle Vintage Wall Decor', '6kb5ifoaSMv7LogDh3PM.jpeg', 'Hiasan dinding circle warna hitam, gold, putih', 'Tersedia', 150000),
(22, 3, 'Modern Circle Wall Decor ', 'zla3nT0FDMg6E1BkyDRf.jpeg', 'Hiasan dinding modern circle warna gold', 'Tersedia', 200000);

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `id` int(11) NOT NULL,
  `username` varchar(50) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `role` enum('admin','user') NOT NULL DEFAULT 'user'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id`, `username`, `password`, `role`) VALUES
(1, 'admin', '$2y$10$Pd5ngNwxeP0bNLUdhLu15eHiD/Pczf9jeoDcVNwHSlWQKDK7yE74a', 'admin'),
(2, 'adel', 'adel123', 'user'),
(6, 'adel', '$2y$10$16hvixkEK8JO2905NoQURuOYUx/C8g7xYCN5Scc.PzezNYnfmRdaS', 'user'),
(8, 'adellio', '$2y$10$KpuwHWOiEuBnotnbIJbdou2aoa/Nq132jRBRnnuFf8jT01XzlA/gW', 'user');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `kategori`
--
ALTER TABLE `kategori`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `produk`
--
ALTER TABLE `produk`
  ADD PRIMARY KEY (`id`),
  ADD KEY `nama` (`nama`),
  ADD KEY `kategori_produk` (`kategori_id`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `kategori`
--
ALTER TABLE `kategori`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `orders`
--
ALTER TABLE `orders`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `produk`
--
ALTER TABLE `produk`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `produk`
--
ALTER TABLE `produk`
  ADD CONSTRAINT `kategori_produk` FOREIGN KEY (`kategori_id`) REFERENCES `kategori` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
