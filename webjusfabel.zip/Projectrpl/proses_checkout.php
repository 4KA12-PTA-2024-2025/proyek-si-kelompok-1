<?php
    include 'koneksi.php';

    if ($_SERVER['REQUEST_METHOD'] == 'POST') {
        $nama_pembeli = htmlspecialchars($_POST['nama_pembeli']);
        $alamat = htmlspecialchars($_POST['alamat']);
        $email = htmlspecialchars($_POST['email']);
        $contact = htmlspecialchars($_POST['contact']);
        $nama_produk = htmlspecialchars($_POST['nama_produk']);
        $harga = htmlspecialchars($_POST['harga']);

        $query = "INSERT INTO orders (nama_pembeli, alamat, email, contact, nama_produk, harga)
        VALUES ('$nama_pembeli', '$alamat', '$email', '$contact', '$nama_produk', '$harga')";

        if (mysqli_query($conn, $query)) {
            // diarahkan ke halaman success.php
            header("Location: success.php");
        } else {
            echo "Error: " . $query . "<br>" . mysqli_error($conn);
        }
    }
?>