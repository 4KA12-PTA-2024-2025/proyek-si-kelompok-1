<?php 
    include 'koneksi.php';

    if(isset($_GET['p'])) {
        $nama = htmlspecialchars($_GET['p']);
        $queryProduk = mysqli_query($conn, "SELECT * FROM produk WHERE nama='$nama'");
        $produk = mysqli_fetch_array($queryProduk);
    } else {
        echo "Produk tidak ditemukan.";
        exit;
    }
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Checkout</title>

    <!-- === bootsrap5 & fontawesome === -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://kit.fontawesome.com/8585918b38.js" crossorigin="anonymous"></script>
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>

    <link rel="stylesheet"  href="asset/style.css">
</head>
<body>
    <!-- Navbar  -->
    <?php include 'navbar.php'; ?>

    <!-- Checkout -->
    <div class="container py-5">
        <h2 class="mb-4">Checkout</h2>
        <div class="row">
            <div class="col-lg-6">
                <h4>Detail Produk</h4>
                <img src="image/<?php echo $produk['foto']; ?>" class="w-100 mb-3" alt="Produk Image">
                <p>Nama Produk: <strong></strong><?php echo $produk['nama']; ?></strong></p>
                <p>Harga: <strong>Rp. <?php echo $produk['harga']; ?>,00</strong></p>
                <p>Stok Barang: <strong><?php echo $produk['stok']; ?></strong></p>
            </div>
            <div class="col-lg-6">
                <h4>Informasi Pembeli</h4>
                <form action="proses_checkout.php" method="POST">
                    <input type="hidden" name="nama_produk" value="<?php echo $produk['nama'] ?>">
                    <input type="hidden" name="harga" value="<?php echo $produk['harga']; ?>">

                    <div class="mb-3">
                        <label for="nama" class="form-label">Nama Pembeli</label>
                        <input type="text" class="form-control" id="nama" name="nama_pembeli" required>
                    </div>
                    <div class="mb-3">
                        <label for="alamat" class="form-label">Alamat</label>
                        <textarea class="form-control" id="alamat" name="alamat" rows="3" required></textarea>
                    </div>
                    <div class="mb-3">
                        <label for="email" class="form-label">Email</label>
                        <input type="email" class="form-control" id="email" name="email" required>
                    </div>
                    <div class="mb-3">
                        <label for="contact" class="form-label">Nomor Handphone</label>
                        <input type="text" class="form-control" id="contact" name="contact" required>
                    </div>
                    <button type="submit" class="btn" style="background-color: #D39D55; color: white; font-weight: 500;">Beli</button>
                </form>
            </div>
        </div>
    </div>

    <!-- Footer -->
    <?php include 'footer.php'; ?>

</body>
</html>