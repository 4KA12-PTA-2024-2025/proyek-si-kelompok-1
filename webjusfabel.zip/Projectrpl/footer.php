<footer class="bg-body-tertiary text-center">
  <!-- Grid container -->
  <div class="container p-4 pb-0">
    <!-- Section: Social media -->
    <section class="mb-4">
      <!-- Facebook -->
      <a
      data-mdb-ripple-init
        class="btn text-white btn-floating m-1"
        style="background-color: #3b5998;"
        href="https://www.facebook.com/share/17yBYnYeRd/?mibextid=wwXIfr"
        role="button"
        ><i class="fab fa-facebook-f"></i
      ></a>

      <!-- WhatsApp -->
      <a
        data-mdb-ripple-init
        class="btn text-white btn-floating m-1"
        style="background-color: #25d366;"
        href=" https://wa.me/6281398618361"
        role="button"
        ><i class='bx bxl-whatsapp'></i>
      </a>

      <!-- Instagram -->
      <a
        data-mdb-ripple-init
        class="btn text-white btn-floating m-1"
        style="background-color: #ac2bac;"
        href="https://www.instagram.com/adeliobifarrel"
        role="button"
        ><i class="fab fa-instagram"></i
      ></a>

    </section>
    <!-- Section: Social media -->
  </div>
  <!-- Grid container -->

  <!-- Copyright -->
  <div class="text-center p-3" style="background-color: #D39D55;">
    <p class="text-white">© 2024 Copyright: <a class="no-decoration" href="#">Jusfabel.com</a></p>
  </div>
  <!-- Copyright -->
</footer>