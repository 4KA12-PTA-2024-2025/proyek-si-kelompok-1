<?php
    // session_start();
    include "koneksi.php";
    
    $queryProduk = mysqli_query($conn, "SELECT id, nama, foto, detail, harga FROM produk LIMIT 3");
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Home</title>

    <!-- === bootsrap5 & fontawesome === -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://kit.fontawesome.com/8585918b38.js" crossorigin="anonymous"></script>
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>

    <link rel="stylesheet"  href="asset/style.css">
</head>
<body>
    <?php include 'navbar.php'; ?>

    <!-- banner -->
    <div class="container-fluid banner d-flex align-items-center">
        <div class="container text-center text-white">
            <h1>Selamat Datang di Jusfabel</h1>
            <h4>Ingin cari apa hari ini?</h4>
            <div class="col-8 offset-2">
                <form action="produk1.php" method="get">
                    <div class="input-group input-group-lg my-4">
                        <input type="text" class="form-control" placeholder="Ketik di sini" 
                        aria-label="Recipient's username" aria-describedby="basic-addon2" name="keyword" autocomplete="off">
                        <button class="btn colorbtn" type="submit"><i class="fa-solid fa-magnifying-glass" style="color: #ffffff;"></i></button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!-- highlighted kategori -->
    <div class="container-fluid py-5 bg2">
        <div class="container text-center">
            <h3 style="font-weight: bold">Kategori</h3>

            <div class="row mt-5">
                <div class="col-md-4 mb-3">
                    <div class="tampilan-kategori kategori-lampu d-flex justify-content-center
                    align-items-center">
                        <h4 class="text-white"><a class="no-decoration" href="produk1.php?kategori=Lampu">Lamp</a></h4>
                    </div>
                </div>
                <div class="col-md-4 mb-3">
                    <div class="tampilan-kategori kategori-wall d-flex justify-content-center
                    align-items-center">
                        <h4 class="text-white"><a class="no-decoration" href="produk1.php?kategori=Wall Decor">Wall Decor</a></h4>
                    </div>
                </div>
                <div class="col-md-4 mb-3">
                    <div class="tampilan-kategori kategori-carpet d-flex justify-content-center
                    align-items-center">
                        <h4 class="text-white"><a class="no-decoration" href="produk1.php?kategori=Carpet">Carpet</a></h4>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Tentang kami -->
    <div class="container-fluid py-5 text-light" style="background-color: #D39D55">
        <div class="container text-center">
            <h3 style="font-weight: bold">About Us</h3>
            <p class="fs-5">
                Jusfabel adalah salah satu website e-commerce yang menjual furniture
                untuk rumah anda yang tahan lama dan pastinya harga terjangkau.
            </p>
        </div>
    </div>
    <!-- produk -->
    <div class="container-fluid py-5">
        <div class="container text-center">
            <h3 style="font-weight: bold">Produk</h3>

            <div class="row mt-5">
                <?php while($produk=mysqli_fetch_array($queryProduk)){ ?>
                <div class="col-sm-6 col-md-4 mb-4">
                    <div class="card h-100">
                        <div class="image-box">
                            <img src="image/<?php echo $produk['foto']; ?>" class="card-img-top" alt="...">
                        </div>
                        <div class="card-body">
                            <h5 class="card-title"><?php echo $produk['nama']; ?></h5>
                            <p class="card-text text-truncate"><?php echo $produk['detail']; ?></p>
                            <p class="card-text text-harga">Rp <?php echo $produk['harga']; ?>,00</p>
                            <a href="produk-detail1.php?p=<?php echo $produk['nama']; ?>" class="btn" style="background-color: #D39D55; color: white; font-weight: 500;">Lihat Detail</a>
                        </div>
                    </div>
                </div>
                <?php } ?>
            </div>
            <a class="btn btn-outline-dark mt-3" href="produk1.php">See more</a>
        </div>
    </div>
    <?php include 'footer.php' ?>
</body>
</html>