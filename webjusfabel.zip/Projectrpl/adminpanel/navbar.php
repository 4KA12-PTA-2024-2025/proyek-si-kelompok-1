<nav class="navbar navbar-expand-sm navbar-light" style="background-color: #D7D3BF">
  <div class="container">
    <a class="navbar-brand ms-3" href="index.php">
        <img src="..\image\Jusfabel_logo.png" alt="" width="90" height="50" class="d-inline-block align-text-center">
    </a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#collapsibleNavbar">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="collapsibleNavbar">
      <ul class="navbar-nav mb-3 mb-lg-0 ms-auto me-5">
        <li class=" me-4">
            <a class="nav-link" href="../adminpanel">Home</a>
        </li>
        <li class=" me-4">
            <a class="nav-link" href="kategori.php">Category</a>
        </li>
        <li class=" me-4">
            <a class="nav-link" href="produk.php">Product</a>
        </li>
        <li class=" me-4">
            <a class="nav-link" href="logout.php">Logout</a>
        </li>
      </ul>
    </div>
  </div>
</nav>