<?php 
    include '../koneksi.php';
    include 'session.php';

    // koneksi data ke database tabel orders
    $queryOrder = mysqli_query($conn, "SELECT * FROM orders");
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Order</title>

    <!-- bootstrap beserta kawan-kawannya -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://kit.fontawesome.com/8585918b38.js" crossorigin="anonymous"></script>
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
</head>
<body>
    <?php include "navbar.php"; ?>

    <div class="container mt-5">
        <div class="mt-3 mb-5">
            <h2>List Order</h2>
            <div class="table-responsive">
                <table class="table mt-4">
                    <thead>
                        <tr>
                            <th>No</th>
                            <th>Nama Pembeli</th>
                            <th>Alamat</th>
                            <th>Contact</th>
                            <th>Produk</th>
                            <th>Harga</th>
                            <th>Tanggal Pembelian</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                            $no = 1;

                            // loop data query
                            while ($data = mysqli_fetch_assoc($queryOrder)) {

                                echo "<tr>";
                                echo "<td>{$no}</td>";
                                echo "<td>{$data['nama_pembeli']}</td>";
                                echo "<td>{$data['alamat']}</td>";
                                echo "<td>{$data['contact']}</td>";
                                echo "<td>{$data['nama_produk']}</td>";
                                echo "<td>Rp" . number_format($data['harga'], 0, ',', '.') . "</td>";
                                echo "<td>{$data['created_at']}</td>";
                                echo "</tr>";
    
                                $no++; // Increment nomor urut
                            }
                        ?>
                    </tbody>
                </table>
            </div>
        </div> 
    </div>
</body>
</html>