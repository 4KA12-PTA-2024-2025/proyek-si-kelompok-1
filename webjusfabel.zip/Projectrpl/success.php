<!-- <?php
    include 'koneksi.php';

    $nama = htmlspecialchars($_GET['p']); 
    $queryProduk = mysqli_query($conn, "SELECT * FROM produk WHERE nama='$nama'");
    $produk = mysqli_fetch_array($queryProduk);
?> -->

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Success</title>

    <!-- === bootsrap5 & fontawesome === -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://kit.fontawesome.com/8585918b38.js" crossorigin="anonymous"></script>
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>

    <!-- <link rel="stylesheet"  href="asset/style.css"> -->
    <style>
        body {
            font-family: Arial, sans-serif;
            display: flex;
            flex-direction: column;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
            background-color: #f9f9f9;
            color: #333;
        }
        .success-container {
            text-align: center;
        }
        .success-container .icon {
            font-size: 100px;
            color: #31363F;
        }
        .success-container h1 {
            font-size: 36px;
            margin: 20px 0;
        }
        .success-container p {
            font-size: 18px;
            color: #666;
        }
        .success-container .btn {
            display: inline-block;
            margin-top: 20px;
            padding: 10px 20px;
            font-size: 16px;
            color: #fff;
            background-color: #F29F58;
            text-decoration: none;
            border-radius: 5px;
            transition: background-color 0.3s;
        }
        .success-container .btn:hover {
            background-color: #D39D55;
        }
    </style>
</head>
<body>
    <div class="success-container">
        <i class='bx fa-7x bx-check' style='color:#31363f'></i>
        <h1>Success!</h1>
        <p>Your request has been processed successfully.<br>You’ll receive a confirmation email shortly.</p>
        <a href="index.php" class="btn">Continue Shopping</a>
    </div>
</body>
</html>